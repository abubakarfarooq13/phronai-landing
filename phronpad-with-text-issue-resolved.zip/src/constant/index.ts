export const PHRON_INFO_EMAIL = "info@phron.ai";
