import { defineStyleConfig } from "@chakra-ui/react";

export default defineStyleConfig({
  // Styles for the base style
  baseStyle: {},
  // Styles for the size variations
  sizes: {},
  // Styles for the visual style variations
  variants: {
    primary: {
      color: "#000",
      rounded: "full",
      borderWidth: "3px",
      px: "7",
      borderColor: "brand.primary",
      backgroundImage:
        "linear-gradient(30deg, brand.primary 80%, transparent 50%)",
      fontWeight: "bold",
      backgroundSize: "500px",
      backgroundRepeat: "no-repeat",
      backgroundPosition: "0%",
      transition: "all 500ms ease-in-out",
      _hover: {
        backgroundPosition: { base: "200%", lg: "170%" },
        color: "brand.primary",
        textDecor: "none",
      },
      _active: {
        boxShadow: "0 0 5px 0 brand.primary inset, 0 0 10px 2px",
      },
    },
    black: {
      color: "brand.primary",
      rounded: "full",
      borderWidth: "3px",
      px: "7",
      borderColor: "#000",
      backgroundImage: "linear-gradient(30deg, #000 80%, transparent 50%)",
      fontWeight: "bold",
      backgroundSize: "500px",
      backgroundRepeat: "no-repeat",
      backgroundPosition: "0%",
      transition: "all 500ms ease-in-out",
      _hover: {
        backgroundPosition: { base: "200%", lg: "170%" },
        color: "#000",
        textDecor: "none",
      },
      _active: {
        boxShadow: "0 0 5px 0 #000 inset, 0 0 10px 2px",
      },
    },
    "primary-outline": {
      bgColor: "none",
      color: "brand.primary",
      borderColor: "brand.primary",
      borderWidth: "2px",
      backgroundColor: "transparent",
      transition: "all .15s ease-in-out",
      _hover: {
        boxShadow: "0 0 5px 0 #afd23e inset, 0 0 10px 2px",
        textDecor: "none",
      },
      _active: {
        boxShadow: "none",
      },
    },
  },
  // The default `size` or `variant` values
  defaultProps: {},
});
