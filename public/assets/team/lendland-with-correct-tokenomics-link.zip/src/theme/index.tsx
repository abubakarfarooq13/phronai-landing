import { extendTheme } from "@chakra-ui/react";
import Button from "./Components/Button";

const colors = {
  brand: {
    primary: "#ddfb20",
    "primary-darker": "#afd23e",
  },
};

export default extendTheme({
  colors,
  styles: {
    global: {
      html: {
        scrollBehavior: "smooth",
      },
      body: {
        bgColor: "#04040e",
        color: "#fff",
      },
    },
  },
  components: {
    Button,
  },
});
