import React from "react";
import { useBreakpointValue } from "@chakra-ui/react";
import { Link } from "@chakra-ui/next-js";
import Image from "next/image";

export default function Logo() {
  const logoMaxWidth = useBreakpointValue({ base: "180px", md: "220px" });
  return (
    <Link href="/">
      <Image
        src="/lendland-logo.png"
        alt="logo"
        width={372}
        height={100}
        style={{ maxWidth: logoMaxWidth }}
      />
    </Link>
  );
}
