"use client";

import React from "react";
import { Box, Stack, HStack, Button, Text, Container } from "@chakra-ui/react";
import Logo from "../Logo";
import CDrawer from "./Drawer";
import Link from "next/link";
import { usePathname } from "next/navigation";

export const navLinks = [
  {
    id: 1,
    label: "$LeLa Token",
    href: "/lela-token",
  },
  {
    id: 2,
    label: "Roadmap",
    href: "/roadmap",
  },
  // {
  //   id: 3,
  //   label: "Join Us",
  //   href: "#join-us",
  // },
  // {
  //   id: 4,
  //   label: "Contact",
  //   href: "/contact",
  // },
];

export default function Nav() {
  const pathname = usePathname();

  return (
    <Box pos="relative" zIndex={1}>
      <Container maxW="1260px">
        <Stack
          direction="row"
          py="8"
          mx="auto"
          px={{ base: "4", xl: "0" }}
          alignItems="center"
          justifyContent="space-between"
          spacing="10"
        >
          <Box flexGrow={{ base: 1, lg: "unset" }}>
            <Logo />
          </Box>

          <HStack spacing="10" display={{ base: "none", lg: "flex" }}>
            {navLinks.map((link) => (
              <Text
                as={Link}
                _hover={{
                  opacity: "1",
                }}
                color={link.href === pathname ? "#fff" : "#fff"}
                key={link.id}
                href={link.href}
              >
                {link.label}
              </Text>
            ))}
            <Button
              variant="primary"
              as="a"
              href="https://app.lendland.io"
              display={{ base: "none", md: "flex" }}
              target="_blank"
            >
              Launch App
            </Button>
          </HStack>

          <CDrawer />
        </Stack>
      </Container>
    </Box>
  );
}
