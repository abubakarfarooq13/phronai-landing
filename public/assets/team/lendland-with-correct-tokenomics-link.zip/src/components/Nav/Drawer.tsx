"use client";

import { useState } from "react";
import {
  Drawer,
  DrawerBody,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  useDisclosure,
  Button,
  Box,
  HStack,
  Link as CLink,
  VStack,
  Text,
} from "@chakra-ui/react";
import Logo from "../Logo";
import { RiMenuFoldLine } from "react-icons/ri";
import { LiaDownloadSolid } from "react-icons/lia";
import { navLinks } from ".";
import Link from "next/link";
import { FaDiscord, FaMedium, FaTelegramPlane } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { usePathname } from "next/navigation";

export default function CDrawer() {
  const pathname = usePathname();
  const { isOpen, onOpen, onClose } = useDisclosure();

  const [privateSaleBtnText, setPrivateSaleBtnText] = useState("Private Sale");

  return (
    <>
      <Button
        variant="unstyled"
        onClick={onOpen}
        display={{ base: "flex", lg: "none" }}
      >
        <RiMenuFoldLine size="28px" />
      </Button>
      <Drawer isOpen={isOpen} placement="right" onClose={onClose}>
        <DrawerOverlay />
        <DrawerContent bgColor="#000">
          <DrawerCloseButton />
          <DrawerHeader>
            <Box maxW="150px">
              <Logo />
            </Box>
          </DrawerHeader>

          <DrawerBody>
            <VStack spacing="5" w="full" pt="5" align="start">
              {navLinks.map((link) => (
                <Text
                  as={Link}
                  color={pathname === link.href ? "brand.secondary" : "#fff"}
                  key={link.id}
                  href={link.href}
                  opacity=".8"
                  onClick={onClose}
                >
                  {link.label}
                </Text>
              ))}
              <Button
                variant="primary"
                as="a"
                href="https://app.lendland.io"
                target="_blank"
                w="full"
              >
                Launch App
              </Button>
              <Button
                variant="primary"
                as="a"
                href="https://lendland.io/whitepaper.pdf"
                target="_blank"
                w="full"
              >
                Whitepaper
              </Button>
              <Button
                as={CLink}
                href="https://lendland.io/tokenomics.pdf"
                target="_blank"
                variant="primary"
                px="8"
                py="4"
                rounded="full"
                w="full"
                fontSize={{ "3000px": "lg" }}
              >
                Tokenomics
              </Button>
              <Button
                as={CLink}
                variant="primary"
                px="8"
                py="4"
                rounded="full"
                w="full"
                fontSize={{ "3000px": "lg" }}
                href="https://lendland.io/litepaper.pdf"
                target="_blank"
              >
                Litepaper
              </Button>

              <HStack
                spacing="5"
                py="14px"
                w="full"
                justifyContent="center"
                mt="14px"
              >
                <CLink
                  href="https://twitter.com/socialLendland"
                  target="_blank"
                  _hover={{
                    color: "brand.primary",
                  }}
                >
                  <FaXTwitter size="24px" />
                </CLink>
                <CLink
                  href="https://t.me/Lendland_Portal"
                  target="_blank"
                  _hover={{
                    color: "brand.primary",
                  }}
                >
                  <FaTelegramPlane size="26px" />
                </CLink>
                <CLink
                  // href="https://discord.gg/mCrZbm2sHY"
                  href="https://discord.gg/3SgKDzzyje"
                  target="_blank"
                  _hover={{
                    color: "brand.primary",
                  }}
                >
                  <FaDiscord size="26px" />
                </CLink>

                <CLink
                  href="https://medium.com/@lendland"
                  target="_blank"
                  _hover={{
                    color: "brand.primary",
                  }}
                >
                  <FaMedium size="26px" />
                </CLink>
              </HStack>
            </VStack>
          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </>
  );
}
