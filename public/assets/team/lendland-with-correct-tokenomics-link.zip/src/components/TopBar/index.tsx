"use client";

import React, { useState } from "react";

import { Button, IconButton, Stack, Text, HStack } from "@chakra-ui/react";
import { IoMdClose } from "react-icons/io";

export default function TopBar() {
  const [show, setShow] = useState(true);

  return show ? (
    <Stack
      direction={{ base: "column", sm: "row" }}
      bgColor="brand.primary"
      py="3"
      textAlign="center"
      color="#000"
      justifyContent="center"
      alignItems="center"
    >
      <Text>Users will be able stake LeLa here:</Text>
      <HStack>
        <Button variant="black" size="sm">
          {/* Stake Now */}
          Coming Soon
        </Button>
        <IconButton
          icon={<IoMdClose />}
          aria-label="close button"
          variant="link"
          onClick={() => {
            setShow(false);
          }}
          color="#000"
        />
      </HStack>
    </Stack>
  ) : null;
}
