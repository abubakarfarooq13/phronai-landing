"use client";

import React from "react";
import {
  Box,
  Stack,
  HStack,
  Button,
  Text,
  Container,
  Link as CLink,
} from "@chakra-ui/react";
import Logo from "../Logo";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { FaDiscord, FaTelegramPlane } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { FaMedium } from "react-icons/fa";

export const navLinks = [
  {
    id: 1,
    label: "$LeLa Token",
    href: "/lela-token",
  },
  {
    id: 2,
    label: "Roadmap",
    href: "/roadmap",
  },
  // {
  //   id: 3,
  //   label: "Join Us",
  //   href: "#join-us",
  // },
  // {
  //   id: 4,
  //   label: "Contact",
  //   href: "/contact",
  // },
];

export default function Footer() {
  const pathname = usePathname();

  return (
    <Box bgColor="#000" pos="relative" zIndex={1}>
      <Container maxW="1260px">
        <Stack
          direction={{ base: "column", md: "row" }}
          flexWrap="wrap"
          py="8"
          mx="auto"
          px={{ base: "4", xl: "0" }}
          alignItems="center"
          justifyContent="space-between"
          spacing="10"
          bgColor="#010204"
        >
          <Box flexGrow={{ base: 1, lg: "unset" }}>
            <Logo />
          </Box>

          <HStack spacing="5" py="14px">
            <CLink
              href="https://twitter.com/socialLendland"
              target="_blank"
              _hover={{
                color: "brand.primary",
              }}
            >
              <FaXTwitter size="24px" />
            </CLink>
            <CLink
              href="https://t.me/Lendland_Portal"
              target="_blank"
              _hover={{
                color: "brand.primary",
              }}
            >
              <FaTelegramPlane size="26px" />
            </CLink>
            <CLink
              // href="https://discord.gg/MPBFD8DfuP"
              href="https://discord.gg/HYEnRpvuMv"
              target="_blank"
              _hover={{
                color: "brand.primary",
              }}
            >
              <FaDiscord size="26px" />
            </CLink>

            <CLink
              href="https://medium.com/@lendland"
              target="_blank"
              _hover={{
                color: "brand.primary",
              }}
            >
              <FaMedium size="26px" />
            </CLink>
          </HStack>

          <Stack
            spacing={{ base: "6", md: "10" }}
            direction="row"
            flexWrap="wrap"
          >
            {navLinks.map((link) => (
              <Text
                as={Link}
                _hover={{
                  opacity: "1",
                }}
                color={link.href === pathname ? "brand.secondary" : "#fff"}
                key={link.id}
                href={link.href}
              >
                {link.label}
              </Text>
            ))}
          </Stack>
        </Stack>
      </Container>
    </Box>
  );
}
