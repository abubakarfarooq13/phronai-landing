import type { Metadata } from "next";
import { Manrope } from "next/font/google";
import { Providers } from "./providers";
import "./globals.css";

const manrope = Manrope({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "LendLand - Empowering DeFi with Boba Network.",
  description:
    "LendLand is a cutting-edge blockchain platform dedicated to revolutionizing the lending and borrowing experience within the Boba Network. Our mission is to provide users with intuitive tools and secure measures, making LendLand the preferred choice for DeFi enthusiasts.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={manrope.className}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
