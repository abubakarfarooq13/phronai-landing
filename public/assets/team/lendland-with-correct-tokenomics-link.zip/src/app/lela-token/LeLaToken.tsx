"use client";

import React from "react";
import {
  Box,
  Stack,
  Container,
  Text,
  VStack,
  Link as CLink,
  Grid,
  GridItem,
} from "@chakra-ui/react";
import Image from "next/image";

const Fade = require("react-reveal/Fade");

export default function CLeLaToken() {
  return (
    <>
      <Box overflow="hidden">
        <Container maxW="860px" position="relative">
          <Grid
            gridTemplateColumns={{
              base: "repeat(1, 1fr)",
              md: "repeat(2, 1fr)",
            }}
            gap="40px"
            pt="100px"
            pb={{ base: "160px", md: "60px" }}
          >
            <Fade left>
              <GridItem
                bgImage="/card-bg-2.png"
                bgRepeat="no-repeat"
                bgSize="100% 100%"
                py="8"
                px="10"
              >
                <Image
                  src="/cubic-box.png"
                  alt="cubic box"
                  width={100}
                  height={100}
                />
                <Text pt="5" fontSize="lg">
                  Lending Protocol Distribution <br />{" "}
                  <Text as="span" color="#c1c1c1">
                    of Profits Generated
                  </Text>
                </Text>
              </GridItem>
            </Fade>
            <Fade right>
              <GridItem
                bgImage="/card-bg-2.png"
                bgRepeat="no-repeat"
                bgSize="100% 100%"
                py="8"
                px="10"
              >
                <Image
                  src="/lendland-discount-coin.png"
                  alt="cubic box"
                  width={80}
                  height={80}
                />
                <Text pt="5" fontSize="lg">
                  Discounts <br />{" "}
                  <Text as="span" color="#c1c1c1">
                    when Borrowing from LendLand
                  </Text>
                </Text>
              </GridItem>
            </Fade>

            <Fade left>
              <GridItem
                bgImage="/card-bg-2.png"
                bgRepeat="no-repeat"
                bgSize="100% 100%"
                py="8"
                px="10"
              >
                <Image
                  src="/airdrop.png"
                  alt="cubic box"
                  width={80}
                  height={80}
                />
                <Text pt="5" fontSize="lg">
                  Airdrops and Competitions <br />{" "}
                  <Text as="span" color="#c1c1c1">
                    Eligibility
                  </Text>
                </Text>
              </GridItem>
            </Fade>
          </Grid>
          <Image
            src="/robot-with-more-text.png"
            alt="robot-with-more-text"
            width={700}
            height={512}
            style={{
              position: "absolute",
              right: "-120px",
              bottom: "0px",
            }}
          />
        </Container>
      </Box>
    </>
  );
}
