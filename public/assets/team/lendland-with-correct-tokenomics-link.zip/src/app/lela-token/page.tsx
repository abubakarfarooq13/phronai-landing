import React from "react";
import { Box } from "@chakra-ui/react";
import CLeLaToken from "./LeLaToken";
import Nav from "@/components/Nav";
import TopBar from "@/components/TopBar";
import Footer from "@/components/Footer";
import { Metadata } from "next";
import TokenHeader from "./TokenHeader";

export const metadata: Metadata = {
  title: "Introducing $Lela Token - LendLand",
  description:
    "The primary token of the LendLand Protocol in the Boba Network.",
};

export default function LeLaToken() {
  return (
    <>
      {/* <TopBar /> */}
      <Box className="header" pb={{ md: "30px" }}>
        <Nav />
        <TokenHeader />
      </Box>
      <CLeLaToken />
      <Footer />
    </>
  );
}
