"use client";

import React from "react";
import {
  Box,
  Stack,
  Container,
  Text,
  VStack,
  Link as CLink,
  Grid,
  GridItem,
} from "@chakra-ui/react";
import Image from "next/image";

const Fade = require("react-reveal/Fade");

export default function TokenHeader() {
  return (
    <Box px={{ base: "4", xl: "0" }} id="lela-token">
      <Stack
        direction={{ base: "column-reverse", md: "row" }}
        alignItems="center"
        justifyContent="center"
        spacing="10"
        // pb={{ base: "70px", md: "0px" }}
        pt={{ base: "70px", md: "0px" }}
      >
        <Fade left>
          <Image
            src="/lendland-coins-group.png"
            alt="coins group"
            width={400}
            height={600}
            style={{ marginTop: "70px" }}
          />
        </Fade>
        <Fade right>
          <VStack
            align={{ base: "center", md: "start" }}
            color="#fff"
            spacing="4"
          >
            <Text
              as="h1"
              fontWeight={600}
              textAlign={{ base: "center", md: "start" }}
              fontSize="4xl"
              lineHeight="120%"
            >
              Introducing <br />
              <Text as="span" color="brand.primary">
                $LeLa Token
              </Text>
            </Text>

            <Text
              mt={{ base: "3", md: "0" }}
              textAlign={{ base: "center", md: "start" }}
              color="#fff"
              fontSize="16px"
            >
              The primary token of the LendLand Protocol{" "}
              <Box as="br" display={{ base: "none", lg: "block" }} /> in the
              Boba Network
            </Text>
          </VStack>
        </Fade>
      </Stack>
    </Box>
  );
}
