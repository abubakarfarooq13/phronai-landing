"use client";

import React from "react";
import {
  Box,
  Stack,
  Text,
  VStack,
  Button,
  Grid,
  GridItem,
  UnorderedList,
  ListItem,
} from "@chakra-ui/react";
import Image from "next/image";

const Fade = require("react-reveal/Fade");

export default function CRoadmap() {
  return (
    <Box py={{ base: "70px", md: "100px" }} position="relative" id="roadmap">
      <Image
        src="/bottom-right-shadow.png"
        alt="bottom right shadow"
        width={1200}
        height={700}
        style={{
          position: "absolute",
          bottom: "0px",
          right: "0px",
          zIndex: -1,
        }}
      />
      <Text fontSize="5xl" textAlign="center" mb="5" fontWeight={600}>
        Roadmap
      </Text>

      <Grid
        // gridTemplateColumns="repeat(4, 1fr)"
        maxW="1260px"
        mb="-40px"
        mx="auto"
        mt={{ base: "100px", md: "140px" }}
        zIndex={2}
        position="relative"
        gap="4"
        rowGap={{ base: "20", md: "32" }}
        gridTemplateColumns={{
          base: "repeat(1, 1fr)",
          md: "repeat(2, 1fr)",
          xl: "repeat(4, 1fr)",
        }}
        pl={{ base: "10", md: "20" }}
        pr={{ base: "10", md: "0" }}
        // px={{ base: "10", md: "0" }}
      >
        <GridItem>
          <Fade>
            <Stack direction="row">
              <Image
                src="/roadmap-coin.png"
                alt="roadmap-coin"
                width={120}
                height={100}
              />
              <Box ml="-40px" mt={{ base: "-40px", md: "-80px" }} w="full">
                <Text
                  fontSize="2xl"
                  fontWeight={500}
                  color="brand.primary"
                  mb="5"
                >
                  Q1 2024
                </Text>
                <UnorderedList color="#c1c1c1" spacing="2" fontSize="sm">
                  <ListItem>Platform Demo Launch</ListItem>
                  <ListItem>Litepaper</ListItem>
                </UnorderedList>
              </Box>
            </Stack>
          </Fade>
        </GridItem>
        <GridItem>
          <Fade>
            <Stack direction="row">
              <Image
                src="/roadmap-coin.png"
                alt="roadmap-coin"
                width={120}
                height={100}
              />
              <Box ml="-40px" mt={{ base: "-40px", md: "-80px" }} w="full">
                <Text
                  fontSize="2xl"
                  fontWeight={500}
                  color="brand.primary"
                  mb="5"
                >
                  Q2 2024
                </Text>
                <UnorderedList color="#c1c1c1" spacing="2" fontSize="sm">
                  <ListItem>Project Functionality Enabled</ListItem>
                  <ListItem>Incentive Program for Lenders and Borrows</ListItem>
                  <ListItem>$LeLa Launch</ListItem>
                </UnorderedList>
              </Box>
            </Stack>
          </Fade>
        </GridItem>
        <GridItem>
          <Fade>
            <Stack direction="row">
              <Image
                src="/roadmap-coin.png"
                alt="roadmap-coin"
                width={120}
                height={100}
              />
              <Box ml="-40px" mt={{ base: "-40px", md: "-80px" }} w="full">
                <Text
                  fontSize="2xl"
                  fontWeight={500}
                  color="brand.primary"
                  mb="5"
                >
                  Q3 2024
                </Text>
                <UnorderedList color="#c1c1c1" spacing="2" fontSize="sm">
                  <ListItem>Addition of DeFi Functionalities</ListItem>
                  <ListItem>Application of Liquidity Lockers</ListItem>
                  <ListItem>
                    Grow interactions of users in Boba Network
                  </ListItem>
                </UnorderedList>
              </Box>
            </Stack>
          </Fade>
        </GridItem>
        <GridItem>
          <Fade>
            <Stack direction="row">
              <Image
                src="/roadmap-coin.png"
                alt="roadmap-coin"
                width={120}
                height={100}
              />
              <Box ml="-40px" mt={{ base: "-40px", md: "-80px" }} w="full">
                <Text
                  fontSize="2xl"
                  fontWeight={500}
                  color="brand.primary"
                  mb="5"
                >
                  Q4 2024
                </Text>
                <Text color="#c1c1c1" fontSize="sm">
                  Soon...
                </Text>
                {/* <VStack align="flex-start" spacing="2"></VStack> */}
              </Box>
            </Stack>
          </Fade>
        </GridItem>
      </Grid>

      <Box display={{ base: "none", xl: "block" }}>
        <Image
          src="/roadmap-line.png"
          alt="roadmap-line"
          width={1400}
          height={50}
          style={{
            margin: "0 auto",
          }}
        />
      </Box>

      <Box px={{ base: "4", xl: "0" }}>
        <Fade bottom>
          <VStack
            bgColor="brand.primary"
            px={{ base: "10", md: "14" }}
            py="10"
            maxW="860px"
            rounded="2xl"
            mx="auto"
            textAlign="center"
            spacing="5"
            color="#000"
            mt="100px"
          >
            <Text fontWeight={700} fontSize="4xl">
              Contact Us
            </Text>
            <Text fontWeight={500}>
              Have questions or feedback? Reach out to our team! We&apos;re here
              to assist you on your DeFi journey.
            </Text>
            <Button
              as="a"
              href="mailto:info@lendland.io"
              variant="black"
              py="6"
              px="12"
            >
              Contact Us
            </Button>
          </VStack>
        </Fade>
      </Box>
    </Box>
  );
}
