import Footer from "@/components/Footer";
import Nav from "@/components/Nav";
import TopBar from "@/components/TopBar";
import React from "react";
import CRoadmap from "./Roadmap";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Roadmap - LendLand",
  description: "LendLand Road Map and Vision.",
};

export default function RoadMap() {
  return (
    <>
      {/* <TopBar /> */}
      <Nav />
      <CRoadmap />
      <Footer />
    </>
  );
}
