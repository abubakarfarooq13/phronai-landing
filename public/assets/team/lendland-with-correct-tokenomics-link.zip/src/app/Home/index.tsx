"use client";

import React, { useState } from "react";
import {
  Box,
  Stack,
  Container,
  Text,
  VStack,
  Button,
  Link as CLink,
  Grid,
  GridItem,
  Divider,
  Wrap,
  WrapItem,
  UnorderedList,
  ListItem,
  Image as CImage,
} from "@chakra-ui/react";
import Nav from "@/components/Nav";
import Image from "next/image";
import Hero from "./Hero";
import Footer from "@/components/Footer";
import TopBar from "@/components/TopBar";

const Fade = require("react-reveal/Fade");

export default function CHome() {
  const [exploreLendingButton, setExploreLendingButton] =
    useState("Explore Lending");
  const [startBorrowingButton, setStartBorrowingButton] =
    useState("Explore Borrowing");

  return (
    <Box>
      {/* <TopBar /> */}
      <Box className="header" pb={{ md: "30px" }}>
        <Nav />
        <Hero />
      </Box>

      {/* main */}
      <Box as="main">
        {/* <Image
          src="/shadow-left.png"
          alt="shadow-left"
          width={1000}
          height={800}
          style={{
            position: "absolute",
            left: "0px",
            top: "35%",
            zIndex: -1,
          }}
        /> */}

        <Box
          bgImage="/gradient-bg.png"
          bgRepeat="no-repeat"
          bgSize="cover"
          bgPos="center"
          pt={{ base: "40px", md: "40px" }}
          pb="100px"
          mb={{ base: "70px", md: "80px" }}
        >
          <Fade bottom>
            <Stack
              mx="auto"
              px={{ base: "4", xl: "0px" }}
              maxW="1260px"
              direction={{ base: "column", md: "row" }}
              spacing={{ base: "20", md: "8" }}
              mt="24"
            >
              <VStack
                px="10"
                py="8"
                maxW={{ base: "full", md: "50%" }}
                bgImage="/card-bg.png"
                bgSize="100% 100%"
                spacing="4"
              >
                <Image
                  src="/lendland-token.png"
                  alt="lendland-token-1"
                  width={130}
                  height={130}
                  style={{
                    marginTop: "-80px",
                  }}
                />
                <Text fontSize="4xl" fontWeight={700}>
                  Lending
                </Text>
                <Text color="#c1c1c1" textAlign="center">
                  Users will be allowed to provide Liquidity for the Borrowing
                  process, earning them a certain APY for the asset contributed.
                </Text>
                <Text color="#c1c1c1" textAlign="center">
                  After a certain period, the lenders will be able to take their
                  liquidity alongside their earnings.
                </Text>
              </VStack>

              <VStack
                px="10"
                py="8"
                maxW={{ base: "full", md: "50%" }}
                bgImage="/card-bg.png"
                bgSize="100% 100%"
                spacing="4"
              >
                <Image
                  src="/lendland-icon.png"
                  alt="lendland-icon"
                  width={130}
                  height={150}
                  style={{
                    marginTop: "-80px",
                  }}
                />
                <Text fontSize="4xl" fontWeight={700}>
                  Borrowing
                </Text>
                <Text color="#c1c1c1" textAlign="center">
                  From the Liquidity provided, users will be able to borrow a
                  certain amount by using a collateral.
                </Text>
                <Text color="#c1c1c1" textAlign="center">
                  This collateral will work as a safety measure for the lenders.
                </Text>
              </VStack>
            </Stack>
          </Fade>
        </Box>

        <Box
          position="relative"
          pb={{ base: "100px", md: "120px" }}
          px={{ base: "4", xl: "0" }}
        >
          {/* <Fade bottom>
            <Text
              textTransform="uppercase"
              // fontSize="lg"
              color="brand.primary-darker"
              letterSpacing="10px"
              lineHeight={{ base: "28px", lg: "20px" }}
              fontWeight={300}
              textAlign="center"
              mb="5"
              fontSize={{ base: "sm", md: "base" }}
            >
              From on site to another
            </Text>
          </Fade> */}

          <Fade bottom>
            <Text
              as="h1"
              fontWeight={500}
              textAlign="center"
              fontSize={{ base: "3xl", md: "4xl" }}
              lineHeight="120%"
              mb="2"
            >
              Lending and Borrowing
            </Text>
          </Fade>

          <Fade bottom>
            <Text
              as="h1"
              fontWeight={500}
              textAlign="center"
              fontSize={{ base: "3xl", md: "4xl" }}
              lineHeight="120%"
              color="brand.primary"
            >
              Made Easy
            </Text>
          </Fade>

          <Stack
            direction={{ base: "column", md: "row" }}
            justifyContent="center"
            alignItems="center"
            spacing="10"
            mt={{ base: "8", md: "20" }}
          >
            <Fade left>
              <VStack
                zIndex={1}
                pt={{ md: "20px", lg: "0px" }}
                w="full"
                maxW="380px"
                align={{ base: "center", md: "start" }}
                spacing={{ base: "3", md: "6" }}
              >
                <Text
                  as="h1"
                  fontWeight={500}
                  textAlign={{ base: "center", md: "start" }}
                  fontSize="5xl"
                  lineHeight="120%"
                >
                  Amenities
                </Text>

                <Text
                  mt={{ base: "3", md: "0" }}
                  textAlign={{ base: "center", md: "start" }}
                  color="#c1c1c1"
                  fontSize="16px"
                >
                  To support the growth of a chain, the users need the best
                  tools available in DeFi.
                </Text>
                <Text
                  mt={{ base: "3", md: "0" }}
                  textAlign={{ base: "center", md: "start" }}
                  color="#c1c1c1"
                  fontSize="16px"
                >
                  Lending and borrowing is not an exemption.
                </Text>

                <Button
                  mt={{ base: "5", md: "0" }}
                  as={CLink}
                  href="https://app.lendland.io"
                  target="_blank"
                  variant="primary"
                  px="8"
                  py="4"
                  rounded="full"
                  fontSize={{ "3000px": "lg" }}
                  // onMouseEnter={() => {
                  //   setExploreLendingButton("Coming Soon");
                  // }}
                  // onMouseLeave={() => {
                  //   setExploreLendingButton("Explore Lending");
                  // }}
                >
                  Explore Lending
                </Button>
              </VStack>
            </Fade>
            <Fade right>
              {/* <Image
                src="/dashboard-home.png"
                alt="dashboard"
                width={700}
                height={700}
              /> */}
              <CImage
                src="/dashboard-home.png"
                alt="dashboard home"
                rounded="xl"
                boxShadow="xl"
              />
            </Fade>
          </Stack>

          {/* <Image
            src="/shadow-right-1.png"
            width={1200}
            height={600}
            alt="shadow right 1"
            style={{
              position: "absolute",
              right: "0px",
              bottom: "0px",
              zIndex: -1,
            }}
          /> */}
        </Box>

        <Box
          pt={{ md: "50px" }}
          // my={{ md: "-50px" }}
          pb={{ base: "50px", md: "0px" }}
          // bgImage="/bottom-left-shadow.png"
          bgPos="left"
          bgSize="100% 100%"
          px={{ base: "4", xl: "0" }}
        >
          <Stack
            direction={{ base: "column", md: "row" }}
            justifyContent="center"
            spacing={{ base: "0", md: "16" }}
            alignItems="center"
          >
            <Fade left>
              {/* <Image
                src="/dashboard-home-2.png"
                alt="dashboard"
                width={700}
                height={700}
              /> */}

              <Image
                src="/dashboard-new.jpg"
                alt="dashboard"
                width={700}
                height={700}
              />
            </Fade>
            <Fade right>
              <VStack
                zIndex={1}
                pt={{ md: "20px", lg: "0px" }}
                w="full"
                maxW="380px"
                align={{ base: "center", md: "start" }}
                spacing={{ base: "3", md: "6" }}
              >
                <Text
                  as="h1"
                  fontWeight={500}
                  textAlign={{ base: "center", md: "start" }}
                  fontSize="5xl"
                  lineHeight="120%"
                >
                  LendLand
                </Text>

                <Text
                  mt={{ base: "3", md: "0" }}
                  textAlign={{ base: "center", md: "start" }}
                  color="#c1c1c1"
                  fontSize="16px"
                >
                  Our mission is to be the go-to place for lending and Borrowing
                  inside Boba Network.
                </Text>
                <Text
                  mt={{ base: "3", md: "0" }}
                  textAlign={{ base: "center", md: "start" }}
                  color="#c1c1c1"
                  fontSize="16px"
                >
                  Providing and intuitive UI and secure code measures, we stand
                  to become the users&apos; preferred choice.
                </Text>

                <Stack direction="row" spacing="4">
                  <Button
                    mt={{ base: "5", md: "0" }}
                    as={CLink}
                    href="https://app.lendland.io"
                    target="_blank"
                    variant="primary"
                    px="8"
                    py="4"
                    rounded="full"
                    fontSize={{ "3000px": "lg" }}
                    // onMouseEnter={() => {
                    //   setStartBorrowingButton("Coming Soon");
                    // }}
                    // onMouseLeave={() => {
                    //   setStartBorrowingButton("Explore Borrowing");
                    // }}
                  >
                    Explore Borrowing
                  </Button>
                </Stack>
              </VStack>
            </Fade>
          </Stack>
        </Box>

        {/* <Divider borderColor="#c1c1c1" /> */}
      </Box>

      <Footer />
    </Box>
  );
}
