import React, { useState } from "react";
import {
  Box,
  Button,
  Container,
  VStack,
  Text,
  Link as CLink,
  Stack,
} from "@chakra-ui/react";
import Image from "next/image";

// @ts-ignore
const Fade = require("react-reveal/Fade");

export default function Hero() {
  const [exploreLendingButton, setExploreLendingButton] =
    useState("Explore Lending");
  const [startBorrowingButton, setStartBorrowingButton] =
    useState("Start Borrowing");

  return (
    <Box as="header">
      <Image
        src="/shadow.png"
        alt="shadow"
        width={1200}
        height={500}
        style={{
          position: "absolute",
          right: "0px",
          zIndex: -1,
        }}
      />
      <Container maxW="1260px">
        <Stack
          direction={{ base: "column", md: "row" }}
          alignItems="center"
          mt={{ lg: "-60px" }}
          justifyContent="space-between"
          pt={{ base: "10", md: "0" }}
        >
          <VStack
            zIndex={1}
            pt={{ md: "20px", lg: "100px" }}
            w="full"
            maxW={{ lg: "450px", xl: "600px" }}
            align={{ base: "center", md: "start" }}
            spacing={{ base: "3", md: "6" }}
          >
            <Fade left>
              <Text
                as="h1"
                fontWeight={500}
                textAlign={{ base: "center", md: "start" }}
                fontSize={{ base: "4xl", md: "5xl" }}
                lineHeight="120%"
              >
                Empowering DeFi <br />
                on{" "}
                <Text color="brand.primary" as="span">
                  Boba Network
                </Text>
                .
              </Text>
            </Fade>

            <Fade left>
              <Text
                mt={{ base: "3", md: "0" }}
                textAlign={{ base: "center", md: "start" }}
                color="#fff"
                fontSize="16px"
                display={{ base: "none", md: "block" }}
              >
                LendLand is a cutting-edge blockchain platform dedicated to
                revolutionizing the lending and borrowing experience within the
                Boba Network. Our mission is to provide users with intuitive
                tools and secure measures, making LendLand the preferred choice
                for DeFi enthusiasts.
              </Text>
            </Fade>
            <Stack
              direction={{ base: "column", sm: "row" }}
              spacing={{ sm: "4" }}
              w="full"
              justifyContent={{ base: "center", md: "flex-start" }}
              display={{ base: "none", md: "flex" }}
            >
              <Fade left>
                <Button
                  mt={{ base: "5", md: "0" }}
                  as={CLink}
                  href="https://lendland.io/whitepaper.pdf"
                  target="_blank"
                  variant="primary"
                  px="8"
                  py="4"
                  rounded="full"
                  w="full"
                  fontSize={{ "3000px": "lg" }}
                >
                  Whitepaper
                </Button>
              </Fade>

              <Fade left>
                <Button
                  mt={{ base: "5", md: "0" }}
                  as={CLink}
                  href="https://lendland.io/tokenomics.pdf"
                  target="_blank"
                  variant="primary"
                  px="8"
                  py="4"
                  rounded="full"
                  w="full"
                  fontSize={{ "3000px": "lg" }}
                >
                  Tokenomics
                </Button>
              </Fade>
              <Fade left>
                <Button
                  mt={{ base: "5", md: "0" }}
                  as={CLink}
                  variant="primary"
                  px="8"
                  py="4"
                  rounded="full"
                  w="full"
                  fontSize={{ "3000px": "lg" }}
                  href="https://lendland.io/litepaper.pdf"
                  target="_blank"
                >
                  Litepaper
                </Button>
              </Fade>
            </Stack>
          </VStack>

          <Fade right>
            <Box mb={{ base: "10", md: "none" }}>
              <Image
                // src="/hero-img.png"
                src="/hero-new-img.png"
                alt="hero-image"
                width={600}
                height={567}
              />
            </Box>
          </Fade>
          <Fade left>
            <Text
              mt={{ base: "3", md: "0" }}
              textAlign={{ base: "center", md: "start" }}
              color="#fff"
              display={{ base: "block", md: "none" }}
              fontSize="16px"
            >
              LendLand is a cutting-edge blockchain platform dedicated to
              revolutionizing the lending and borrowing experience within the
              Boba Network. Our mission is to provide users with intuitive tools
              and secure measures, making LendLand the preferred choice for DeFi
              enthusiasts.
            </Text>
          </Fade>
          <Stack
            direction={{ base: "column", sm: "row" }}
            spacing={{ sm: "4" }}
            w="full"
            justifyContent={{ base: "center", md: "flex-start" }}
            display={{ base: "flex", md: "none" }}
          >
            <Fade left>
              <Button
                mt={{ base: "5", md: "0" }}
                as={CLink}
                href="https://lendland.io/whitepaper.pdf"
                target="_blank"
                variant="primary"
                px="8"
                py="4"
                rounded="full"
                w="full"
                fontSize={{ "3000px": "lg" }}
              >
                Whitepaper
              </Button>
            </Fade>

            <Fade left>
              <Button
                mt={{ base: "5", md: "0" }}
                as={CLink}
                href="https://lendland.io/tokenomics.pdf"
                target="_blank"
                variant="primary"
                px="8"
                py="4"
                rounded="full"
                w="full"
                fontSize={{ "3000px": "lg" }}
              >
                Tokenomics
              </Button>
            </Fade>
            <Fade left>
              <Button
                mt={{ base: "5", md: "0" }}
                as={CLink}
                variant="primary"
                px="8"
                py="4"
                rounded="full"
                w="full"
                fontSize={{ "3000px": "lg" }}
                href="https://lendland.io/litepaper.pdf"
                target="_blank"
              >
                Litepaper
              </Button>
            </Fade>
          </Stack>
        </Stack>
      </Container>
    </Box>
  );
}
